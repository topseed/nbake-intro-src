( if maintainer, edit index js to use package
	import { Srv, FileOps } from 'meta-admin/lib/ABase'
	and copy sample www_admin pages
 )


npm i

edit admin.yaml

// path to admin
node index.js .