npm i

x.cmd